const data = {
    name: '尚硅谷atguigu'
};

handle(data);